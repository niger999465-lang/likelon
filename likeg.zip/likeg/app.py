import asyncio, aiohttp, json, socket, time, struct, re, uuid, random, requests
import threading
from datetime import datetime, timedelta
from flask import Flask, jsonify, request as flask_request
from Crypto.Cipher import AES as _AES
from Crypto.Util.Padding import pad
import blackboxprotobuf as pb

DB1_FILE     = "accs_db1.txt"
DB2_FILE     = "accs_db2.txt"
INDEX_FILE   = "accsIndex.txt"
DB1_BATCH    = 200
DB2_BATCH    = 200
MAX_LIKE_COUNT  = 100
TOKEN_REFRESH_SECONDS = 5 * 3600

app = Flask(__name__)

state_lock = threading.Lock()
state = {
 "accs_used"  : 0,
 "accs_count" : 0,
 "tokens"  : [],
 "info_token" : None,
 "no_accs" : False,
}


def parse_results(parsed_results):
 result_dict = {}
 for result in parsed_results:
  if result.field not in result_dict:
   result_dict[result.field] = []
  if result.wire_type in ("varint", "string", "bytes"):
   field_data = result.data
  elif result.wire_type == "length_delimited":
   field_data = parse_results(result.data.results)
  else:
   field_data = result.data
  result_dict[result.field].append(field_data)
 return {k: v[0] if len(v) == 1 else v for k, v in result_dict.items()}


def Varint(value: int) -> bytes:
 value &= 0xFFFFFFFFFFFFFFFF
 result = bytearray()
 while value > 0x7F:
  result.append((value & 0x7F) | 0x80)
  value >>= 7
 result.append(value)
 return bytes(result)


class PBE:
 def CVF(self, field, value):
  return Varint((field << 3) | 0) + Varint(value)

 def CLF(self, field, value):
  v = value.encode() if isinstance(value, str) else value
  return Varint((field << 3) | 2) + Varint(len(v)) + v

 def decode(self, data):
  fields, _ = pb.decode_message(data)
  inner = fields.get('1') or fields.get(1)
  if isinstance(inner, bytes):
   try: fields, _ = pb.decode_message(inner)
   except Exception: pass
  return fields

 def encode(self, fields: dict) -> bytes:
  packet = bytearray()
  for field, value in fields.items():
   field = int(field)
   values = value if isinstance(value, list) else [value]
   for item in values:
    if isinstance(item, dict):
     packet.extend(self.CLF(field, self.encode(item)))
    elif isinstance(item, int):
     packet.extend(self.CVF(field, item))
    elif isinstance(item, (str, bytes)):
     packet.extend(self.CLF(field, item))
    else: raise TypeError(f"Unsupported type: {type(item)}")
  return bytes(packet)


class AESCipher:
 def __init__(self, key: bytes, iv: bytes):
  self.key = key
  self.iv  = iv

 def enc(self, data: bytes) -> bytes:
  return _AES.new(self.key, _AES.MODE_CBC, self.iv).encrypt(pad(data, 16))


def random_android_os() -> str:
 versions = [
  (12, "SP1A", "210812.016", "Q"),
  (11, "RP1A", "200720.011", "R"),
  (13, "TP1A", "221005.002", "T"),
  (10, "QP1A", "190711.020", "Q"),
 ]
 v = random.choice(versions)
 gdpr_date = (
  f"GDPR.{random.randint(2021,2023)}"
  f"{random.randint(1,12):02}{random.randint(1,28):02}"
  f"{random.randint(10,23):02}{random.randint(10,59):02}"
  f"{random.randint(10,59):02}"
 )
 return f"Android OS {v[0]} / API-{30 + v[0] - 10} ({v[1]}.{v[2]}.016/{v[3]}.{gdpr_date})"


def random_opengl() -> str:
 minor = random.randint(1, 2)
 v2    = random.randint(20, 45)
 patch = ''.join(random.choices('abcdef0123456789', k=8))
 hash_str = ''.join(random.choices('abcdef0123456789', k=32))
 return f"OpenGL ES 3.{minor} v1.r{v2}p1-01eac0.{patch}{hash_str[:24]}"


def random_google_uuid() -> str:
 return f"Google|{uuid.uuid4()}"


def random_device() -> str:
 model_map = {
  "OPPO"   : ["CPH2161","CPH2219","CPH2251","CPH2357","CPH2385"],
  "Samsung": ["SM-G991B","SM-A525F","SM-S908B","SM-A135F"],
  "Xiaomi" : ["2201123G","22111317I","2107113SG","21121119SC"],
  "Realme" : ["RMX3301","RMX3085","RMX3471","RMX2001"],
  "Vivo"   : ["V2109","V2111","V2205","V2145"],
 }
 brand = random.choice(list(model_map))
 return f"{brand} {random.choice(model_map[brand])}"


def generate_device_info() -> dict:
 return {
  "android_os": random_android_os(),
  "opengl" : random_opengl(),
  "google_uid": random_google_uuid(),
  "device" : random_device(),
 }


sapp = lambda pkg: (
 (re.findall(r'\[\[\["(\d+\.\d+\.\d+)"\]\]',
  requests.get("https://play.google.com/store/apps/%s" % pkg).text)
  or [None])[0]
)

common = lambda ver: (
 (lambda v:
  requests.get(
   "https://version.common.redflamenco.com/live/ver.php"
   "?version=%s&lang=vi&device=android&region=VN" % v
  ).json()
 )(ver or sapp("details?id=com.dts.freefireth"))
)

_RF_CACHE = "redflamenco_cache.json"
try:
 redflamenco = common(sapp("details?id=com.dts.freefireth"))
 with open(_RF_CACHE, "w", encoding="utf-8") as _f:
  json.dump(redflamenco, _f)
except Exception as _e:
 # Lấy version từ Google Play/redflamenco lỗi -> dùng lại bản đã lưu lần chạy trước
 print(f"[!] Không lấy được version game ({_e}). Thử dùng cache {_RF_CACHE}...")
 try:
  with open(_RF_CACHE, "r", encoding="utf-8") as _f:
   redflamenco = json.load(_f)
  print("[+] Đã dùng cache version.")
 except Exception:
  raise RuntimeError("Không lấy được version game và chưa có cache. Kiểm tra mạng của host rồi chạy lại.")

proto = PBE()


class HTTPRequest:
 def __init__(self, region: str = "vn"):
  self.language  = region
  self.auth_res: dict  = {}
  self.base_url  = redflamenco["server_url"]
  self.client_version  = redflamenco["remote_version"]
  self.release_version = redflamenco["latest_release_version"]
  self._session: aiohttp.ClientSession | None = None
  self.cipher = AESCipher(
   bytes([89,103,38,116,99,37,68,69,117,104,54,37,90,99,94,56]),
   bytes([54,111,121,90,68,114,50,50,69,51,121,99,104,106,77,37])
  )
  self.ip = socket.inet_ntoa(struct.pack(">I", random.randint(*random.choice(
   [(0x0EA00001, 0x0EBFFFFE), (0x76440001, 0x7647FFFE)]
  ))))

 def BaseHeader(self) -> dict:
  h = {}
  h["User-Agent"]   = "UnityPlayer/2022.3.47f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)"
  h["Accept"]    = "*/*"
  h["Accept-Encoding"] = "gzip, br"
  h["Cf-Visitor"]   = '{"scheme":"https"}'
  h["X-Ga"]   = "v1 1"
  h["X-Unity-Version"] = "2022.3.47f1"
  h["Content-Type"] = "application/x-www-form-urlencoded"
  h["Releaseversion"]  = self.release_version
  h["X-Forwarded-For"] = self.ip
  h["X-Real-IP"]    = self.ip
  h["Client-IP"]    = self.ip
  h["X-GA-SV"]   = str(int(time.time()))
  return h

 async def __aenter__(self):
  self._session = aiohttp.ClientSession(headers=self.BaseHeader())
  return self

 async def __aexit__(self, *_):
  if self._session:
   await self._session.close()

 async def auth_guest_token(self, uid: str, password: str):
  url = "https://100067.connect.garena.com/api/v2/oauth/guest/token:grant"
  payload = {
   "uid"    : int(uid),
   "password"  : password,
   "response_type": "token",
   "client_type"  : 1,
   "client_id" : 100067,
   "client_secret": bytes([
    50,101,101,52,52,56,49,57,101,57,98,52,53,57,56,56,52,53,49,52,49,48,54,55,
    98,50,56,49,54,50,49,56,55,52,100,48,100,53,100,55,97,102,57,100,56,102,55,
    101,48,48,99,49,101,53,52,55,49,53,98,55,100,49,101,51,
   ]).decode(),
  }
  headers = {
   'User-Agent': "GarenaMSDK/4.0.44(TEST-XIAOMI-037 ;Android 13;en;HK;app 1.132.1 2019121227;)",
   'Connection': "Keep-Alive",
   'Accept': "application/json",
   'Accept-Encoding': "gzip",
   'Content-Type': "application/json; charset=utf-8"
 }
 
  async with self._session.post(url, json=payload, headers=headers) as resp:
   data = await resp.json(content_type=None)
  if not data["data"].get("access_token"):
   raise ValueError("ERR_ACCOUNT_NOT_FOUND")
  self.auth_res = data["data"]

 def _login_fields(self) -> dict:
  did, ar = generate_device_info(), self.auth_res
  fields = {
    '100': str(ar.get("platform")),
    '102': b'KS\x11\x15XU\x0bUf',
    '104': 83297,
    '105': 1,
    '106': b'https://dl.ak.freefiremobile.com/live/ABHotUpdates/|https://core-ak.'
           b'freefiremobile.com/live/ABHotUpdates/|211c933168f55902c7dfbfd8c4e295'
           b'7d',
    '107': b'c8e41b7a93f02d56e1a94c7b8203f5d1',
    '11': b'WIFI',
    '12': 1666,
    '13': 750,
    '14': b'480',
    '15': b'ARM64 FP ASIMD AES | 2000 | 8',
    '16': 7535,
    '17': b'Mali-G57 MC3',
    '18': did["opengl"],
    '19': did["google_uid"],
    '20': self.ip,
    '21': self.language,
    '22': ar.get("open_id"),
    '23': str(ar.get("main_active_platform")),
    '24': 'Handheld',
    '25': did["device"],
    '26': 'VN',
    '29': ar.get("access_token"),
    '3': time.strftime("%Y-%m-%d %H:%M:%S"),
    '30': 1,
    '4': b'free fire',
    '42': b'WIFI',
    '5': 1,
    '57': b'7428b253defc164018c604a1ebbfebdf',
    '60': 111125,
    '61': 56494,
    '62': 646,
    '64': 56712,
    '65': 111125,
    '66': 56712,
    '67': 111125,
    '7': self.client_version,
    '73': 1,
    '74': b'/data/app/~~h0JP-7-LHRc8iezKCTZQYQ==/com.dts.freefireth-rdQdDZibr0Yk'
           b'riX7zeYmew==/lib/arm64',
    '76': 1,
    '77': b'b8e0cd5e295eee42f5860d3c86e483dd|/data/app/~~h0JP-7-LHRc8iezKCTZQYQ='
           b'=/com.dts.freefireth-rdQdDZibr0YkriX7zeYmew==/base.apk',
    '78': 3,
    '79': 2,
    '8': did["android_os"],
    '81': b'64',
    '83': b'2019121229',
    '85': 3,
    '86': b'OpenGLES2',
    '87': 4095,
    '88': 4,
    '9': b'Handheld',
    '92': 8288,
    '93': b'android',
    '94': b'KqsHT4jYHMuXpNnqCxMrcpvAA7VRIqzcddnQLgUv22cgjJmRn03mZIsMfmujKufoEieX'
           b'Y4lZEMaea8FznYlJ7PciWLa+IjupG1nK71uk3O5woF6U',
    '95': 111207,
    '96': b'{"cur_rate":[60,90],"support_etc2":false}',
    '97': 1,
    '99': str(ar.get("platform")),
}
  return fields

 async def MajorLogin(self) -> bytes:
  x = self.cipher.enc(proto.encode(self._login_fields()))
  async with self._session.post(self.base_url + "MajorLogin", data=x) as r:
   return await r.read()

 async def GetPlayerBriefInfo(self, cid: int, token: str) -> bytes:
  headers = {
   "Authorization": f"Bearer {token}",
   "X-GA-SV"   : str(int(time.time()))
  }
  async with self._session.post(
   "https://clientbp.ppmainecoonghj.com/GetAccountInfoByAccountID",
   data=self.cipher.enc(proto.encode({1: cid, 2: 1})),
   headers=headers
  ) as r:
   return await r.read()

 async def LikeProfile(self, cid: int, token: str) -> bytes:
  headers = {
   "Authorization": f"Bearer {token}",
   "X-GA-SV"   : str(int(time.time()))
  }
  async with self._session.post(
   "https://clientbp.ppmainecoonghj.com/LikeProfile",
   data=self.cipher.enc(proto.encode({1: cid, 2: 1})),
   headers=headers
  ) as r:
   return await r.read()


def read_accounts(filepath: str) -> list[tuple[str, str]]:
 accs = []
 try:
  with open(filepath, "r", encoding="utf-8") as f:
   for line in f:
    line = line.strip()
    if ":" in line:
     uid, pwd = line.split(":", 1)
     accs.append((uid.strip(), pwd.strip()))
 except FileNotFoundError: pass
 return accs


import pytz as _pytz

def _reset_epoch_vn() -> float:
 vn_tz = _pytz.timezone("Asia/Ho_Chi_Minh")
 now   = datetime.now(vn_tz)
 reset = vn_tz.localize(datetime(now.year, now.month, now.day, 1, 0, 0))
 return reset.timestamp()

def save_index():
 with open(INDEX_FILE, "w") as f:
  f.write(f"AccsUsed: {state['accs_used']}\n")
  f.write(f"AccsCount: {state['accs_count']}\n")
  f.write(f"SavedAt: {time.time()}\n")


def load_index():
 try:
  saved_at  = None
  accs_used = 0
  accs_count= 0
  with open(INDEX_FILE, "r") as f:
   for line in f:
    if line.startswith("AccsUsed:"):
     accs_used  = int(line.split(":")[1].strip())
    elif line.startswith("AccsCount:"):
     accs_count = int(line.split(":")[1].strip())
    elif line.startswith("SavedAt:"):
     saved_at   = float(line.split(":", 1)[1].strip())

  reset_epoch = _reset_epoch_vn()
  if saved_at is None or saved_at < reset_epoch:
   state["accs_used"]  = 0
   state["accs_count"] = 0
  else:
   state["accs_used"]  = accs_used
   state["accs_count"] = accs_count
  save_index()
 except FileNotFoundError:
  save_index()


_token_errors = []

async def fetch_token(uid: str, pwd: str) -> str | None:
 try:
  async with HTTPRequest(region="vn") as req:
   await req.auth_guest_token(uid, pwd)
   lr = await req.MajorLogin()
   token = proto.decode(lr[64:])["8"].decode()
   return token
 except Exception as e:
  if len(_token_errors) < 3:
   _token_errors.append(f"{uid}: {type(e).__name__}: {e}")
  return None


async def _load_batch_tokens(db1_accs: list, db2_accs: list) -> list[tuple[str, str]]:
 all_accs = db1_accs + db2_accs
 results  = await asyncio.gather(*[fetch_token(uid, pwd) for uid, pwd in all_accs])
 tokens   = []
 for (uid, _), token in zip(all_accs, results):
  if token:
   tokens.append((uid, token))
 print(f"[TOKEN] Đăng nhập thành công {len(tokens)}/{len(all_accs)} acc")
 if not tokens and all_accs:
  print("[TOKEN] TẤT CẢ acc đều đăng nhập lỗi. Ví dụ lỗi:")
  for _e in _token_errors:
   print("   ", _e)
  print("   (kiểm tra: sai uid/password, acc bị khóa, mạng chặn máy chủ game, hoặc game đã update version)")
 _token_errors.clear()
 return tokens


async def _fetch_batch_at(db1_start: int, db2_start: int) -> list | None:
 all_db1 = read_accounts(DB1_FILE)
 all_db2 = read_accounts(DB2_FILE)

 db1_slice = all_db1[db1_start : db1_start + DB1_BATCH]
 db2_slice = all_db2[db2_start : db2_start + DB2_BATCH]

 if not db1_slice and not db2_slice:
  with state_lock:
   state["no_accs"] = True
  return None

 return await _load_batch_tokens(db1_slice, db2_slice)


_refresh_lock: asyncio.Lock | None = None


async def refresh_batch_tokens(rotate: bool = False):
 global _refresh_lock
 if _refresh_lock is None:
  _refresh_lock = asyncio.Lock()
 async with _refresh_lock:
  with state_lock:
   state["no_accs"] = False
   current_used = state["accs_used"]

  if rotate:
   next_used = current_used + DB1_BATCH + DB2_BATCH
   batch_no  = next_used // (DB1_BATCH + DB2_BATCH) - 1
  else:
   batch_no  = current_used // (DB1_BATCH + DB2_BATCH) if current_used > 0 else 0

  db1_start = batch_no * DB1_BATCH
  db2_start = batch_no * DB2_BATCH

  tokens = await _fetch_batch_at(db1_start, db2_start)
  if tokens is None:
   return

  with state_lock:
   state["tokens"]  = tokens
   state["no_accs"] = False
   if rotate:
    state["accs_used"]  = current_used + DB1_BATCH + DB2_BATCH
    state["accs_count"] = 0
  save_index()



async def token_refresh_loop():
 await refresh_batch_tokens()
 while True:
  await asyncio.sleep(TOKEN_REFRESH_SECONDS)
  await refresh_batch_tokens()


async def daily_reset():
 print("[RESET] Daily reset at 01:00 AM UTC+7")
 with state_lock:
  state["accs_used"]  = 0
  state["accs_count"] = 0
  state["no_accs"]    = False
  state["tokens"]     = []
 save_index()
 await refresh_batch_tokens(rotate=False)

def scdr(loop: asyncio.AbstractEventLoop):
 vn_tz = _pytz.timezone("Asia/Ho_Chi_Minh")
 while True:
  now = datetime.now(vn_tz)
  next_reset = vn_tz.localize(datetime(now.year, now.month, now.day, 1, 0, 0))
  if next_reset <= now: next_reset += timedelta(days=1)
  wait_secs = (next_reset - now).total_seconds()
  time.sleep(wait_secs)
  asyncio.run_coroutine_threadsafe(daily_reset(), loop)


_async_loop: asyncio.AbstractEventLoop | None = None


def rasc(loop: asyncio.AbstractEventLoop):
 asyncio.set_event_loop(loop)
 loop.run_forever()


def _submit(coro):
 return asyncio.run_coroutine_threadsafe(coro, _async_loop).result()


@app.route("/LikeProfile")
def v1Likes():
 uid_str = flask_request.args.get("uid")
 if not uid_str or not uid_str.isdigit():
  return "INVALID_ACCOUNT", 400

 uid = int(uid_str)

 # Giới hạn số acc like trong 1 request (không truyền = dùng cả batch)
 try:
  max_likes = max(1, int(flask_request.args.get("limit", 100000)))
 except ValueError:
  max_likes = 100000

 with state_lock:
  if not state["tokens"]:
   tokens_snapshot = None
   trigger_refresh = True
   rotate = False
  elif state["accs_count"] >= MAX_LIKE_COUNT:
   state["tokens"]     = []
   state["accs_count"] = 0
   tokens_snapshot     = None
   trigger_refresh     = True
   rotate              = True
  else:
   tokens_snapshot = list(state["tokens"])
   trigger_refresh = False
   rotate          = False

 if tokens_snapshot is None:
  all_db1 = read_accounts(DB1_FILE)
  all_db2 = read_accounts(DB2_FILE)
  with state_lock:
   batch_no = state["accs_used"] // (DB1_BATCH + DB2_BATCH)
  if batch_no * DB1_BATCH >= len(all_db1) and batch_no * DB2_BATCH >= len(all_db2):
   with state_lock:
    state["no_accs"] = True
   print(f"[!] HẾT ACC: accs_db1={len(all_db1)}, accs_db2={len(all_db2)} acc, đã dùng tới đợt {batch_no}. "
         f"Thêm acc vào file hoặc xóa accsIndex.txt rồi chạy lại.")
   return "SERVICE_NOT_AVAILABLE", 503

  # Vừa đăng nhập thất bại hàng loạt thì nghỉ 60s, đừng thử lại ở mỗi request
  if time.time() - state.get("last_fail", 0) < 60:
   return "SERVICE_NOT_AVAILABLE", 503

  _submit(refresh_batch_tokens(rotate=rotate))

  with state_lock:
   tokens_snapshot = list(state["tokens"])
  if not tokens_snapshot:
   state["last_fail"] = time.time()
   return "SERVICE_NOT_AVAILABLE", 503

 async def _do_all():
  async with HTTPRequest(region="vn") as req:
   try:
    raw_before   = await req.GetPlayerBriefInfo(uid, tokens_snapshot[0][1])
    info   = proto.decode(raw_before)
    nickname  = info.get("3",  b"").decode()
    region    = info.get("5",  b"").decode()
    likes_before = info.get("21", 0)
    
   except Exception:
    return 0, 0, 0, 0

   async def _read_likes():
    raw = await req.GetPlayerBriefInfo(uid, tokens_snapshot[0][1])
    return proto.decode(raw).get("21", 0)

   pool = list(tokens_snapshot)
   random.shuffle(pool)   # chọn acc ngẫu nhiên, không cố định các acc đầu danh sách
   likes_after = likes_before
   total_sent = 0
   total_err = 0
   for _wave in range(4):
    need = max_likes - (likes_after - likes_before)
    if need <= 0 or not pool:
     break
    wave, pool = pool[:need], pool[need:]
    res = await asyncio.gather(*[req.LikeProfile(uid, tk) for _, tk in wave], return_exceptions=True)
    total_sent += len(wave)
    total_err += sum(1 for r in res if isinstance(r, Exception))
    await asyncio.sleep(3)             # server game cập nhật số like chậm
    likes_after = await _read_likes()
    if likes_after > likes_before:
     await asyncio.sleep(2)
     likes_after = await _read_likes()
   print(f"[LIKE] UID {uid}: đã thử {total_sent} acc (lỗi mạng {total_err}), like {likes_before} -> {likes_after}")

  return nickname, region, likes_before, likes_after

 nickname, region, likesBefore, likesAfter = _submit(_do_all())
 if not nickname:
  return "INVALID_ACCOUNT", 400

 LikesAdded = likesAfter - likesBefore
 with state_lock:
  state["accs_count"] += 1
 save_index()

 fields = {}
 fields["NickName"] = nickname
 fields["LikesBefore"] = likesBefore
 fields["LikesAfter"] = likesAfter
 fields["UserID"] = uid
 fields["Region"] = region
 fields["Added"] = LikesAdded
 return fields, 200



load_index()
asyncLoop = asyncio.new_event_loop()
_async_loop = asyncLoop
threading.Thread(target=rasc, args=(asyncLoop,), daemon=True).start()

while not asyncLoop.is_running():
 time.sleep(0.3)

asyncio.run_coroutine_threadsafe(token_refresh_loop(), asyncLoop)
threading.Thread(target=scdr, args=(asyncLoop,), daemon=True).start()
# Chỉ tự chạy server khi chạy thẳng "python app.py". Khi bot.py import app.py thì
# bot.py sẽ tự chạy Flask ở luồng riêng (nếu không, import sẽ bị treo và bot không bao giờ lên).
if __name__ == "__main__":
 app.run(host="0.0.0.0", port=2001, debug=False, use_reloader=False)
