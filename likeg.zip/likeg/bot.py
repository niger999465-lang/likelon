import os
import json
import time
import threading
import random
import requests
from datetime import datetime
import pytz
import telebot
from apscheduler.schedulers.background import BackgroundScheduler

# True  = bot.py tự chạy luôn API (app.py) trong cùng 1 tiến trình (khuyên dùng khi host chỉ chạy 1 file: bot.py)
# False = API (app.py) đã được host chạy riêng ở FLASK_PORT, bot chỉ gọi tới nó
START_FLASK_IN_BOT = True

HAS_FLASK_APP = False
if START_FLASK_IN_BOT:
    try:
        from app import app as flask_app
        HAS_FLASK_APP = True
    except Exception as e:
        import traceback
        print("[!] KHÔNG IMPORT ĐƯỢC app.py -> API nội bộ sẽ KHÔNG chạy (lỗi Connection refused). Chi tiết:")
        traceback.print_exc()

# ================= CẤU HÌNH BOT =================
BOT_TOKEN = "8972688177:AAH4pm1bdNKAyuCiUDJYiemCvW9cQ1HBh4w"

# Danh sách ID Telegram của Admin (Lấy ID tại @userinfobot)
ADMIN_IDS = [8593804261,8480206805,8959721595]

# ID nhóm thông báo kết quả Auto Like lúc 5h sáng (Để 0 nếu chỉ muốn gửi riêng cho Admin)
NOTIFY_CHAT_ID = 0 

# Giới hạn số lần dùng lệnh /flike mỗi ngày cho 1 người dùng Free
FREE_DAILY_LIMIT = 3

# Đường dẫn API nội bộ từ app.py (Chỉnh lại nếu route trong app.py của bạn khác)
# Cổng chạy API nội bộ (app.py). Chạy trên PC: dùng 5000.
FLASK_PORT = 5000
API_URL_TEMPLATE = "http://127.0.0.1:" + str(FLASK_PORT) + "/LikeProfile?uid={uid}"

# /flike (user Free) chỉ được random 30-40 like mỗi lần
FREE_LIKE_MIN = 30
FREE_LIKE_MAX = 40

# Danh sách ID box (nhóm) được phép dùng bot. Có thể thêm bằng lệnh /addbox trong box.
# Box lấy ID bằng lệnh /ping. Ví dụ: [-1001234567890]
ALLOWED_CHAT_IDS = []
# Cho phép user thường nhắn riêng với bot không? (False = chỉ Admin nhắn riêng được)
ALLOW_PRIVATE_FOR_ALL = False

# Bắt buộc tham gia ĐỦ các box dưới đây mới được dùng /flike (Admin được miễn).
# "id": ID box/kênh (lấy bằng /ping trong box đó, dạng -100xxxxxxxxxx)
# "link": link mời để hiện nút cho user bấm vào
# LƯU Ý: bot phải ở trong box đó (kênh thì phải là Admin) mới kiểm tra được thành viên.
REQUIRED_CHATS = [
    {"id": -1004399849288, "name": "Box 1", "link": "https://t.me/Muyybufflike"},
    {"id": "@muystore", "name": "Muy Store", "link": "https://t.me/muystore"},
]

DATA_FILE = "bot_data.json"
VN_TZ = pytz.timezone("Asia/Ho_Chi_Minh")
# ================================================

class _SafeExceptionHandler(telebot.ExceptionHandler):
    """Lỗi gửi tin (vd: bot bị cấm chat trong 1 box) chỉ in 1 dòng, không làm sập/khởi động lại polling."""
    def handle(self, exception):
        msg = str(exception)
        if "not enough rights" in msg or "have no rights" in msg or "CHAT_WRITE_FORBIDDEN" in msg:
            print("[!] Bot KHÔNG có quyền gửi tin trong 1 box -> cấp quyền gửi tin / cho bot làm Admin trong box đó.")
        else:
            print(f"[!] Lỗi khi xử lý lệnh: {msg}")
        return True

bot = telebot.TeleBot(BOT_TOKEN, parse_mode="HTML", exception_handler=_SafeExceptionHandler())

# Quản lý dữ liệu (Danh sách Auto Like & Lượt dùng Free)
def load_data():
    if not os.path.exists(DATA_FILE):
        return {"autolike": [], "free_usage": {}, "last_reset": "", "allowed_chats": []}
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"autolike": [], "free_usage": {}, "last_reset": "", "allowed_chats": []}

def save_data(data):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

def check_and_reset_daily_free(data):
    today_str = datetime.now(VN_TZ).strftime("%Y-%m-%d")
    if data.get("last_reset") != today_str:
        data["free_usage"] = {}
        data["last_reset"] = today_str
        save_data(data)

# Hàm gọi API buff like
def execute_like(uid: str, limit: int = None) -> dict:
    url = API_URL_TEMPLATE.format(uid=uid)
    if limit:
        url += f"&limit={limit}"
    try:
        # Có limit (flike) thì chờ tối đa 120s; full acc (adlike/alike) có thể rất lâu nên chờ tới 20 phút
        res = requests.get(url, timeout=120 if limit else 1200)
        try:
            data = res.json()
        except Exception:
            data = res.text.strip()

        # API mới trả lỗi dạng text: INVALID_ACCOUNT / SERVICE_NOT_AVAILABLE
        if isinstance(data, str):
            if data == "INVALID_ACCOUNT":
                data = {"error": "UID không hợp lệ hoặc không tồn tại (hoặc không đọc được thông tin UID)", "status": 0}
            elif data == "SERVICE_NOT_AVAILABLE":
                data = {"error": "Hết acc hoặc dịch vụ tạm ngưng (SERVICE_NOT_AVAILABLE). Kiểm tra file accs_db1/accs_db2.txt", "status": 0}

        # Đổi tên key của API mới sang key mà bot đang đọc
        if isinstance(data, dict) and "NickName" in data:
            data = {
                "PlayerNickname": data.get("NickName"),
                "LikesbeforeCommand": data.get("LikesBefore"),
                "LikesafterCommand": data.get("LikesAfter"),
                "LikesGivenByAPI": data.get("Added"),
                "UID": data.get("UserID"),
                "Region": data.get("Region"),
                "status": 1,
            }
        return {"success": True, "data": data, "status": res.status_code}
    except requests.exceptions.ConnectionError:
        return {"success": False, "error": "API nội bộ (app.py, cổng " + str(FLASK_PORT) + ") chưa chạy hoặc đã sập. Xem console của bot để biết lỗi."}
    except Exception as e:
        return {"success": False, "error": str(e)}

def format_like_response(uid: str, result: dict, mode_label: str) -> str:
    if not result["success"]:
        return f"❌ <b>[{mode_label}] Lỗi kết nối API cho UID <code>{uid}</code>:</b>\n<code>{result['error']}</code>"
    
    data = result["data"]
    # API báo lỗi (UID sai, hết acc...)
    if isinstance(data, dict) and data.get("error") and "PlayerNickname" not in data:
        return f"❌ <b>[{mode_label}] Không buff được cho UID</b> <code>{uid}</code>:\n<code>{data['error']}</code>"
    # Nếu API trả về JSON phổ biến của các source Like FF
    if isinstance(data, dict):
        name = data.get("PlayerNickname") or data.get("nickname") or data.get("name") or "Không rõ"
        before = data.get("LikesbeforeCommand") or data.get("likes_before") or "?"
        after = data.get("LikesafterCommand") or data.get("likes_after") or "?"
        added = data.get("LikesGivenByAPI")
        if added is None:
            added = data.get("likes_added")
        status = data.get("status")

        # Không tăng được like nào (+0) => UID đã max like trong ngày
        try:
            maxed = added is not None and int(added) == 0
        except (ValueError, TypeError):
            maxed = False
        if maxed and any(k in data for k in ["PlayerNickname", "nickname"]):
            return (
                f"⚠️ <b>[{mode_label}] UID NÀY ĐÃ MAX LIKE, ĐỢI ĐẾN 5H SÁNG</b>\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"👤 <b>Tên NV:</b> <code>{name}</code>\n"
                f"🆔 <b>UID:</b> <code>{uid}</code>\n"
                f"📈 <b>Like hiện tại:</b> <code>{after}</code>\n"
                f"⏰ <b>Thời gian:</b> {datetime.now(VN_TZ).strftime('%H:%M:%S %d/%m/%Y')}"
            )
        if added is None:
            added = "?"
        
        if any(k in data for k in ["PlayerNickname", "LikesGivenByAPI", "likes_added", "nickname"]):
            return (
                f"✅ <b>[{mode_label}] BUFF LIKE THÀNH CÔNG</b>\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"👤 <b>Tên NV:</b> <code>{name}</code>\n"
                f"🆔 <b>UID:</b> <code>{uid}</code>\n"
                f"📈 <b>Like trước:</b> <code>{before}</code>\n"
                f"🚀 <b>Like sau:</b> <code>{after}</code> (+<code>{added}</code>)\n"
                f"⏰ <b>Thời gian:</b> {datetime.now(VN_TZ).strftime('%H:%M:%S %d/%m/%Y')}"
            )
    
    # Nếu trả về dạng text hoặc JSON cấu trúc khác
    return (
        f"✅ <b>[{mode_label}] Đã xử lý UID:</b> <code>{uid}</code>\n"
        f"📄 <b>Phản hồi từ Server:</b>\n<code>{str(data)[:800]}</code>"
    )
# ================= CHẶN BOX LẠ =================
def is_allowed_chat(chat) -> bool:
    if chat.type == "private":
        return ALLOW_PRIVATE_FOR_ALL
    if chat.id in ALLOWED_CHAT_IDS:
        return True
    return chat.id in load_data().get("allowed_chats", [])

def is_required_chat(chat) -> bool:
    """Box/kênh nằm trong REQUIRED_CHATS thì bot KHÔNG được tự rời."""
    uname = ("@" + chat.username.lower()) if getattr(chat, "username", None) else None
    for c in REQUIRED_CHATS:
        cid = c.get("id")
        if cid == chat.id or (uname and isinstance(cid, str) and cid.lower() == uname):
            return True
    return False

# Handler này PHẢI đăng ký đầu tiên: ai không phải Admin mà dùng ở box chưa duyệt thì bị chặn
@bot.message_handler(func=lambda m: m.from_user.id not in ADMIN_IDS and not is_allowed_chat(m.chat))
def block_unauthorized(message):
    if message.chat.type not in ("private", "channel") and not is_required_chat(message.chat):
        try:
            bot.leave_chat(message.chat.id)  # bot tự rời box chưa được duyệt
        except Exception:
            pass

# Bot bị add vào box lạ -> tự rời nếu người add không phải Admin
@bot.my_chat_member_handler()
def on_added_to_chat(update):
    chat = update.chat
    if chat.type in ("private", "channel"):
        return  # kênh: không tự rời (cần để bot làm Admin kiểm tra thành viên)
    if is_required_chat(chat):
        return
    if update.new_chat_member.status in ("member", "administrator"):
        if update.from_user.id not in ADMIN_IDS and not is_allowed_chat(chat):
            try:
                bot.leave_chat(chat.id)
            except Exception:
                pass

@bot.message_handler(commands=["addbox", "delbox"])
def handle_box_admin(message):
    if message.from_user.id not in ADMIN_IDS:
        return
    data = load_data()
    chats = data.setdefault("allowed_chats", [])
    cid = message.chat.id
    if message.text.startswith("/addbox"):
        if cid not in chats:
            chats.append(cid)
            save_data(data)
        bot.reply_to(message, f"✅ Đã <b>DUYỆT</b> box này (<code>{cid}</code>). Thành viên có thể dùng bot.")
    else:
        if cid in chats:
            chats.remove(cid)
            save_data(data)
        bot.reply_to(message, f"🗑️ Đã <b>GỠ</b> box <code>{cid}</code> khỏi danh sách được phép.")

# ================= LỆNH /info (CHECK INFO FF) =================
@bot.message_handler(commands=["info"])
def handle_info(message):
    args = message.text.split()
    if len(args) < 2 or not args[1].isdigit():
        bot.reply_to(
            message,
            "⚠️ <b>Cú pháp:</b> <code>/info &lt;UID&gt;</code>\n"
            "Ví dụ: <code>/info 123456789</code>"
        )
        return

    uid = args[1]
    wait_msg = bot.reply_to(message, f"🔍 Đang tra cứu thông tin UID <code>{uid}</code>...")

    api_url = f"https://infogtdevob55.vercel.app/info?uid={uid}"
    try:
        res = requests.get(api_url, timeout=25)
        if res.status_code != 200:
            bot.edit_message_text(
                f"❌ <b>Lỗi từ máy chủ API (Mã lỗi: {res.status_code})</b>\nKhông tìm thấy hoặc không thể lấy thông tin UID <code>{uid}</code>.",
                chat_id=message.chat.id,
                message_id=wait_msg.message_id
            )
            return

        data = res.json()

        # Tự động nhận diện các cấu trúc JSON phổ biến của API Info OB55
        basic = data.get("basicInfo") or data.get("AccountInfo") or data.get("data") or data
        clan = data.get("clanBasicInfo") or data.get("GuildInfo") or {}
        social = data.get("socialInfo") or data.get("SocialInfo") or {}

        if isinstance(basic, dict) and any(k in basic for k in ["nickname", "AccountName", "level", "AccountLevel", "liked", "AccountLikes"]):
            name = basic.get("nickname") or basic.get("AccountName") or "Không rõ"
            level = basic.get("level") or basic.get("AccountLevel") or "?"
            exp = basic.get("exp") or basic.get("AccountEXP") or "?"
            likes = basic.get("liked") or basic.get("AccountLikes") or "?"
            region = basic.get("region") or basic.get("AccountRegion") or "VN"
            
            # Chuyển đổi thời gian tạo acc / đăng nhập cuối nếu là timestamp
            create_at = basic.get("createAt") or basic.get("AccountCreateTime") or "Không rõ"
            if str(create_at).isdigit() and int(create_at) > 100000000:
                create_at = datetime.fromtimestamp(int(create_at), VN_TZ).strftime("%H:%M:%S %d/%m/%Y")

            last_login = basic.get("lastLoginAt") or basic.get("AccountLastLogin") or "Không rõ"
            if str(last_login).isdigit() and int(last_login) > 100000000:
                last_login = datetime.fromtimestamp(int(last_login), VN_TZ).strftime("%H:%M:%S %d/%m/%Y")

            clan_name = (clan.get("clanName") or clan.get("GuildName") or "Không có") if isinstance(clan, dict) else "Không có"
            bio = (social.get("signature") or social.get("AccountSignature") or basic.get("signature") or "Trống") if isinstance(social, dict) else "Trống"

            info_text = (
                f"🎮 <b>THÔNG TIN TÀI KHOẢN FREE FIRE</b>\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"👤 <b>Tên NV:</b> <code>{name}</code>\n"
                f"🆔 <b>UID:</b> <code>{uid}</code>\n"
                f"🌍 <b>Khu vực:</b> <code>{region}</code>\n"
                f"⭐ <b>Level:</b> <code>{level}</code> (EXP: <code>{exp}</code>)\n"
                f"❤️ <b>Lượt Like:</b> <code>{likes}</code>\n"
                f"🛡️ <b>Quân đoàn:</b> <code>{clan_name}</code>\n"
                f"📅 <b>Ngày tạo:</b> <code>{create_at}</code>\n"
                f"🕒 <b>Đăng nhập cuối:</b> <code>{last_login}</code>\n"
                f"📝 <b>Tiểu sử:</b> <code>{bio}</code>"
            )
        else:
            # Nếu JSON có tên trường khác biệt, hiển thị toàn bộ JSON đã làm đẹp
            formatted_json = json.dumps(data, indent=2, ensure_ascii=False)
            if len(formatted_json) > 3500:
                formatted_json = formatted_json[:3500] + "\n... (đã rút gọn)"
            info_text = (
                f"🎮 <b>THÔNG TIN UID:</b> <code>{uid}</code>\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"<pre>{formatted_json}</pre>"
            )

        bot.edit_message_text(info_text, chat_id=message.chat.id, message_id=wait_msg.message_id)

    except Exception as e:
        bot.edit_message_text(
            f"❌ <b>Lỗi khi kiểm tra UID <code>{uid}</code>:</b>\n<code>{str(e)}</code>",
            chat_id=message.chat.id,
            message_id=wait_msg.message_id
        )


# ================= LỆNH /help & /start =================
@bot.message_handler(commands=["help", "start"])
def handle_help(message):
    user_id = message.from_user.id
    is_admin = user_id in ADMIN_IDS

    help_text = (
        f"🔥 <b>HƯỚNG DẪN SỬ DỤNG BOT BUFF LIKE FF</b> 🔥\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"👤 <b>Lệnh cho Thành viên:</b>\n"
        f"• <code>/flike &lt;UID&gt;</code> : Buff like miễn phí ({FREE_DAILY_LIMIT} lần/ngày, {FREE_LIKE_MIN}-{FREE_LIKE_MAX} like/lần)\n"
        f"  <i>Ví dụ:</i> <code>/flike 123456789</code>\n"
        f"• <code>/help</code> : Xem bảng hướng dẫn này\n"
    )

    # Nếu người gõ là Admin thì hiện thêm menu đặc quyền
    if is_admin:
        help_text += (
            f"\n👑 <b>Lệnh đặc quyền Admin:</b>\n"
            f"• <code>/adlike &lt;UID&gt;</code> : Buff like không giới hạn lượt\n"
            f"• <code>/alike &lt;UID&gt;</code> : Thêm/Xóa UID vào danh sách Auto 05:00 sáng\n"
            f"• <code>/alike list</code> : Xem danh sách UID đang chạy Auto\n"
            f"• <code>/alike run</code> : Chạy test Auto Like ngay lập tức\n"
            f"• <code>/addbox</code> : Duyệt box hiện tại được dùng bot\n"
            f"• <code>/delbox</code> : Gỡ box hiện tại\n"
        )

    help_text += (
        f"━━━━━━━━━━━━━━━━━━\n"
        f"🆔 <b>ID của bạn:</b> <code>{user_id}</code>\n"
        f"💬 <b>ID Box hiện tại:</b> <code>{message.chat.id}</code>\n"
        f"⏰ <i>Lượt Free làm mới vào 00:00 | Auto Like chạy lúc 05:00 sáng.</i>"
    )

    bot.reply_to(message, help_text)

# ================= BẮT BUỘC VÀO ĐỦ BOX =================
def get_missing_chats(user_id: int):
    """Trả về (box_chua_vao, box_bot_loi). box_bot_loi = bot không kiểm tra được (sai ID / bot chưa vào box / chưa là Admin kênh)."""
    missing, broken = [], []
    for c in REQUIRED_CHATS:
        if not c.get("id"):
            continue  # chưa cấu hình ID thì bỏ qua
        try:
            m = bot.get_chat_member(c["id"], user_id)
            joined = m.status in ("member", "administrator", "creator") or \
                     (m.status == "restricted" and getattr(m, "is_member", True))
            if not joined:
                missing.append(c)
        except Exception as e:
            print(f"[LỖI CHECK BOX] {c['id']} | user {user_id}: {e}")
            broken.append(c)
    return missing, broken

@bot.message_handler(commands=["testbox"])
def handle_testbox(message):
    """Admin: kiểm tra từng box bắt buộc, hiện rõ lỗi."""
    if message.from_user.id not in ADMIN_IDS:
        return
    me = bot.get_me()
    lines = ["🔎 <b>Kiểm tra REQUIRED_CHATS</b>"]
    for c in REQUIRED_CHATS:
        cid = c.get("id")
        if not cid:
            lines.append(f"• {c['name']}: ⚠️ id = 0 (chưa điền, đang bị bỏ qua)")
            continue
        try:
            chat = bot.get_chat(cid)
            bm = bot.get_chat_member(cid, me.id)
            um = bot.get_chat_member(cid, message.from_user.id)
            lines.append(
                f"• {c['name']} (<code>{cid}</code>): ✅ tìm thấy <b>{chat.title}</b>\n"
                f"   Bot: <b>{bm.status}</b> | Bạn: <b>{um.status}</b>"
                + ("" if bm.status in ("administrator", "creator") else "\n   ⚠️ Bot chưa là Admin → kênh sẽ không kiểm tra được")
            )
        except Exception as e:
            lines.append(f"• {c['name']} (<code>{cid}</code>): ❌ <code>{e}</code>")
    bot.reply_to(message, "\n".join(lines))
# ================= THÔNG BÁO CHUNG =================
import html
import time as _time

REMINDER_TEXT  = "Nhớ vào đủ box để dùng /flike nhé! Mỗi ngày được 5 lượt."
REMINDER_HOURS = [8, 20]       # Giờ tự động nhắc trên các box. Để [] nếu không muốn tự nhắc

def track_user(message):
    """Ghi nhớ người dùng để sau này nhắn riêng được."""
    data = load_data()
    users = data.setdefault("users", [])
    if message.from_user.id not in users:
        users.append(message.from_user.id)
        save_data(data)

def get_all_boxes():
    ids = set(ALLOWED_CHAT_IDS) | set(load_data().get("allowed_chats", []))
    return list(ids)

def broadcast_boxes(text):
    """Gửi lên tất cả box đã duyệt."""
    ok = fail = 0
    for cid in get_all_boxes():
        try:
            bot.send_message(cid, text)
            ok += 1
        except Exception as e:
            fail += 1
            print(f"[TB] Không gửi được lên box {cid}: {e}")
        _time.sleep(0.5)
    return ok, fail

def broadcast_private(text):
    """Nhắn riêng cho từng người đã từng dùng bot."""
    data = load_data()
    users = list(data.get("users", []))
    ok = fail = 0
    dead = []
    for u in users:
        try:
            bot.send_message(u, text)
            ok += 1
        except Exception as e:
            fail += 1
            if any(k in str(e) for k in ("blocked", "deactivated", "chat not found")):
                dead.append(u)   # người đã chặn bot / xóa tài khoản
        _time.sleep(0.1)         # ~10 tin/giây, an toàn với giới hạn của Telegram
    if dead:
        data = load_data()
        data["users"] = [x for x in data.get("users", []) if x not in dead]
        save_data(data)
    return ok, fail

def reminder_job():
    broadcast_boxes(f"📢 <b>NHẮC NHỞ</b>\n━━━━━━━━━━━━━━━━━━\n{html.escape(REMINDER_TEXT)}")

@bot.message_handler(commands=["tb", "tbrieng", "tball"])
def handle_broadcast(message):
    if message.from_user.id not in ADMIN_IDS:
        return
    parts = message.text.split(None, 1)
    cmd = parts[0].split("@")[0].lower()
    if len(parts) < 2:
        bot.reply_to(message,
            "📢 <b>Gửi thông báo (Admin)</b>\n"
            "• <code>/tb nội dung</code> : gửi lên các box\n"
            "• <code>/tbrieng nội dung</code> : nhắn riêng từng người\n"
            "• <code>/tball nội dung</code> : cả hai")
        return
    text = f"📢 <b>THÔNG BÁO</b>\n━━━━━━━━━━━━━━━━━━\n{html.escape(parts[1])}"

    def job():
        lines = []
        if cmd in ("/tb", "/tball"):
            ok, fail = broadcast_boxes(text)
            lines.append(f"📦 Box: {ok} thành công, {fail} lỗi")
        if cmd in ("/tbrieng", "/tball"):
            ok, fail = broadcast_private(text)
            lines.append(f"👤 Nhắn riêng: {ok} thành công, {fail} lỗi")
        bot.send_message(message.chat.id, "✅ <b>Đã gửi xong</b>\n" + "\n".join(lines))

    threading.Thread(target=job, daemon=True).start()   # chạy nền để bot không bị đứng
    bot.reply_to(message, "⏳ Đang gửi thông báo...")




# ================= LỆNH /flike (FREE USER) =================
# Lệnh kiểm tra xem bot đã nhận tin nhắn trong Box chưa
@bot.message_handler(commands=["ping", "start"])
def handle_ping(message):
    print(f"[LOG] Nhận lệnh từ Chat ID: {message.chat.id} | User ID: {message.from_user.id} | Nội dung: {message.text}")
    bot.reply_to(
        message,
        f"🟢 <b>Bot đang hoạt động!</b>\n"
        f"• <b>ID của bạn:</b> <code>{message.from_user.id}</code>\n"
        f"• <b>ID Box hiện tại:</b> <code>{message.chat.id}</code>"
    )
@bot.message_handler(commands=["flike"])
def handle_free_like(message):
    user_id = str(message.from_user.id)
    args = message.text.split()
    
    if len(args) < 2 or not args[1].isdigit():
        bot.reply_to(message, "⚠️ <b>Cú pháp:</b> <code>/flike &lt;UID&gt;</code>\nVí dụ: <code>/flike 123456789</code>")
        return

    uid = args[1]

    # Phải vào đủ các box bắt buộc mới được buff (Admin miễn)
    if message.from_user.id not in ADMIN_IDS:
        missing, broken = get_missing_chats(message.from_user.id)
        if broken:
            names = ", ".join(c["name"] for c in broken)
            bot.reply_to(
                message,
                f"⚠️ Bot chưa kiểm tra được box <b>{names}</b> (sai ID/username, hoặc bot chưa ở trong box / chưa là Admin).\n"
                f"Vui lòng báo Admin kiểm tra!"
            )
            return
        if missing:
            from telebot import types
            kb = types.InlineKeyboardMarkup()
            for c in missing:
                kb.add(types.InlineKeyboardButton(f"👉 Vào {c['name']}", url=c["link"]))
            bot.reply_to(
                message,
                "⛔ Bạn phải tham gia <b>ĐỦ các box</b> bên dưới mới được dùng /flike.\n"
                "Vào xong gõ lại lệnh nhé!",
                reply_markup=kb
            )
            return

    data = load_data()
    check_and_reset_daily_free(data)

    used_count = data["free_usage"].get(user_id, 0)
    if used_count >= FREE_DAILY_LIMIT and int(user_id) not in ADMIN_IDS:
        bot.reply_to(
            message,
            f"⛔ Bạn đã hết lượt dùng Free hôm nay (<b>{used_count}/{FREE_DAILY_LIMIT}</b>).\n"
            f"Vui lòng quay lại sau 00:00 hoặc liên hệ Admin!"
        )
        return

    wait_msg = bot.reply_to(message, f"⏳ Đang tiến hành buff like Free cho UID <code>{uid}</code>, vui lòng đợi...")
    result = execute_like(uid, limit=random.randint(FREE_LIKE_MIN, FREE_LIKE_MAX))
    
    if result["success"]:
        data["free_usage"][user_id] = used_count + 1
        save_data(data)

    reply_text = format_like_response(uid, result, "FREE LIKE")
    bot.edit_message_text(reply_text, chat_id=message.chat.id, message_id=wait_msg.message_id)

# ================= LỆNH /adlike (ADMIN) =================
@bot.message_handler(commands=["adlike"])
def handle_admin_like(message):
    if message.from_user.id not in ADMIN_IDS:
        bot.reply_to(message, "⛔ Lệnh này chỉ dành riêng cho <b>Admin</b>!")
        return

    args = message.text.split()
    if len(args) < 2 or not args[1].isdigit():
        bot.reply_to(message, "⚠️ <b>Cú pháp Admin:</b> <code>/adlike &lt;UID&gt;</code>\nVí dụ: <code>/adlike 123456789</code>")
        return

    uid = args[1]
    wait_msg = bot.reply_to(message, f"⚡ <b>[ADMIN]</b> Đang buff like cho UID <code>{uid}</code>...")
    result = execute_like(uid)
    reply_text = format_like_response(uid, result, "ADMIN LIKE")
    bot.edit_message_text(reply_text, chat_id=message.chat.id, message_id=wait_msg.message_id)

# ================= LỆNH /alike (AUTO LIKE 5H SÁNG) =================
@bot.message_handler(commands=["alike"])
def handle_auto_like(message):
    if message.from_user.id not in ADMIN_IDS:
        bot.reply_to(message, "⛔ Chỉ <b>Admin</b> mới có quyền cài đặt Auto Like!")
        return

    args = message.text.split()
    data = load_data()
    autolike_list = data.get("autolike", [])

    if len(args) < 2:
        uid_lines = "\n".join([f"• <code>{u}</code>" for u in autolike_list]) or "<i>(Trống)</i>"
        bot.reply_to(
            message,
            f"📌 <b>QUẢN LÝ AUTO LIKE (05:00 SÁNG)</b>\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"• Thêm/Xóa nhanh UID: <code>/alike &lt;UID&gt;</code>\n"
            f"• Xem danh sách: <code>/alike list</code>\n"
            f"• Chạy test ngay: <code>/alike run</code>\n\n"
            f"📋 <b>Danh sách hiện tại ({len(autolike_list)} UID):</b>\n{uid_lines}"
        )
        return

    sub = args[1].lower()

    if sub == "list":
        uid_lines = "\n".join([f"{i+1}. <code>{u}</code>" for i, u in enumerate(autolike_list)]) or "<i>Chưa có UID nào.</i>"
        bot.reply_to(message, f"📋 <b>DANH SÁCH AUTO LIKE 05:00 SÁNG:</b>\n{uid_lines}")
        return

    if sub == "run":
        bot.reply_to(message, "🔄 Đang kích hoạt chạy Auto Like thủ công...")
        threading.Thread(target=auto_like_job, kwargs={"manual_chat_id": message.chat.id}).start()
        return

    if sub.isdigit():
        if sub in autolike_list:
            autolike_list.remove(sub)
            save_data(data)
            bot.reply_to(message, f"🗑️ Đã <b>XÓA</b> UID <code>{sub}</code> khỏi danh sách Auto Like 5h sáng.")
        else:
            autolike_list.append(sub)
            data["autolike"] = autolike_list
            save_data(data)
            bot.reply_to(message, f"✅ Đã <b>THÊM</b> UID <code>{sub}</code> vào danh sách Auto Like lúc 05:00 sáng hàng ngày!")
    else:
        bot.reply_to(message, "⚠️ UID không hợp lệ! Nhập <code>/alike &lt;UID&gt;</code> để thêm hoặc xóa.")

# ================= TIẾN TRÌNH TỰ ĐỘNG 5H SÁNG =================
def auto_like_job(manual_chat_id=None):
    data = load_data()
    check_and_reset_daily_free(data)
    autolike_list = data.get("autolike", [])

    if not autolike_list:
        return

    target_chats = [manual_chat_id] if manual_chat_id else ([NOTIFY_CHAT_ID] if NOTIFY_CHAT_ID != 0 else ADMIN_IDS)

    for chat_id in target_chats:
        try:
            bot.send_message(
                chat_id,
                f"🌅 <b>BẮT ĐẦU AUTO LIKE ĐỊNH KỲ ({len(autolike_list)} UID)</b>\n"
                f"⏰ Thời gian: {datetime.now(VN_TZ).strftime('%H:%M:%S %d/%m/%Y')}"
            )
        except Exception:
            pass

    for uid in autolike_list:
        res = execute_like(uid)
        msg_text = format_like_response(uid, res, "AUTO 05:00")
        for chat_id in target_chats:
            try:
                bot.send_message(chat_id, msg_text)
            except Exception:
                pass
        time.sleep(3)  # Nghỉ 3s giữa mỗi UID để tránh nghẽn acc trong account_vn.txt

# ================= KHỞI CHẠY HỆ THỐNG =================
def run_flask():
    """Chạy app.py ở luồng nền; nếu sập thì in lỗi và tự khởi động lại."""
    import traceback
    if not HAS_FLASK_APP:
        return
    print("\n[+] Các đường dẫn (Routes) có trong app.py của bạn:")
    for rule in flask_app.url_map.iter_rules():
        print(f"    -> {rule} (Methods: {','.join(rule.methods)})")
    while True:
        try:
            print(f"[+] Đang khởi chạy Flask API tại http://127.0.0.1:{FLASK_PORT} ...\n")
            flask_app.run(host="127.0.0.1", port=FLASK_PORT, debug=False, use_reloader=False)
        except Exception:
            print("[!] Flask API bị sập, chi tiết lỗi:")
            traceback.print_exc()
        time.sleep(5)  # chờ rồi khởi động lại (vd cổng 5000 đang bị chiếm)

if __name__ == "__main__":
    # 1. Chạy Flask app.py ở luồng nền
    if HAS_FLASK_APP:
        flask_thread = threading.Thread(target=run_flask, daemon=True)
        flask_thread.start()
        time.sleep(2)

    # 2. Lập lịch chạy tự động lúc 05:00 sáng giờ Việt Nam
    scheduler = BackgroundScheduler(timezone=VN_TZ)
    scheduler.add_job(auto_like_job, trigger="cron", hour=5, minute=0)
    for h in REMINDER_HOURS:
        scheduler.add_job(reminder_job, trigger="cron", hour=h, minute=0)
    scheduler.start()
    print("[+] Đã bật bộ hẹn giờ Auto Like lúc 05:00 sáng (Asia/Ho_Chi_Minh).")

    # 3. Chạy Telegram Bot
    print("[+] Bot Telegram đang hoạt động...")
    bot.infinity_polling(timeout=60, long_polling_timeout=30,
                         allowed_updates=["message", "edited_message", "callback_query", "my_chat_member"])